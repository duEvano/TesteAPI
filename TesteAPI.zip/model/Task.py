class Task:
    def __init__(self, idTask):
        self.idTask = idTask
