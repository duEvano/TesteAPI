# constantes utilizadas para as demandas do Wrike !
ID_CAMPO_DATA_STATUS = 'IEADYSXZJUACXE75'
ID_FOLDER_BB_DIGITAL = 'IEADYSXZI4QSY3QA'
ID_FOLDER_BB_PROMO = 'IEADYSXZI4QRZ4ZS'

# id do webHook do Bb Digital
ID_WEBHOOK_BB_DIGITAL = 'IEADYSXZJAABCKEE'
ID_WEBHOOK_BB_PROMO = 'IEADYSXZJAABCNAY'

#ids utilizados para Bcommercer
iD_FOLDER_ENTRADA_BCOMMERCE = 'IEADYSXZI42H3JCP'
iD_FOLDER_DOAC_BCOMMERCE = 'IEADYSXZI42SNCV7'
#dica para busca de determinada folder ... Busque sempre pelo permalink